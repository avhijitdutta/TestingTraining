<?php 
$host = '148.72.232.171';
$database = 'tekSpeaks';
$user = 'root';
$password = 'tekspeaks_123';

$response = array("success" => 0 , 'message' => 'cannot process data', 'data' => array());

$params = json_decode(file_get_contents('php://input'),true);


$requestEmail = $params['email'];

$link = mysql_connect($host, $user, $password);	
mysql_select_db($database);

$query = "SELECT COUNT(id) FROM user WHERE email='".$requestEmail."'";
$result = mysql_query($query);
$num_rows = mysql_num_rows($result);
mysql_close($link);

if($num_rows > 0) {
	$response['success'] = 0;
	$response['message'] = 'Email exists';
	$response['data'] = array();
}else {

	// insert one record
	$query = "INSERT INTO user (";
	$i = 0;

	foreach($params as $key => $value) {
		if($i > 0) {
			$query .= ",";
		}
		$query .= $key;
		$i++;
	}

	$query .=") ";

	$query .= "VALUES (";;
	$i = 0;
	foreach($params as $key => $value) {
		if($i > 0) {
			$query .= ",";
		}
		$query .= "'".$value."'";
		$i++;
	}
	$query .=")";

	$link = mysql_connect($host, $user, $password);	
	mysql_select_db($database);
	$result = mysql_query( $query, $link );

	$response['success'] = 1;
	$response['message'] = 'Record inserted successfully';
	$response['data'] = array();
	mysql_close($link);
}


header("Access-Control-Allow-Origin: *");
header("Content-Typ:application/json");
echo json_encode($response);
die();