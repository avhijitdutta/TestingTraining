<?php

$host = '148.72.232.171';
$database = 'tekSpeaks';
$user = 'root';
$password = 'tekspeaks_123';

$request  = $_SERVER['REQUEST_URI'];
$params   = split("/", $request);

$entity = NULL;
$id = NULL;
$query = '';

$method = $_SERVER['REQUEST_METHOD'];
$response = array("success" => 0 , 'message' => 'cannot process data', 'data' => array());

if(isset($params[2]) && !empty($params[2])) {
	// entity
	$entity = $params[2];
}

if(isset($params[3]) && !empty($params[3])) {
	// id
	$id = $params[3];
}

if(!is_null($entity)) {


	if($entity == 'auth' && $method == "POST") {
		$requestEmail = $_POST['email'];
		$requestPassword = $_POST['password'];
		$query = "SELECT * FROM user WHERE email='".$requestEmail."' AND password='".$requestPassword."'";

		$link = mysql_connect($host, $user, $password);	
		mysql_select_db($database);
		$result = mysql_query($query);
		$num_rows = mysql_num_rows( $result);
		
		if($num_rows > 0) {
			// authentication successfull

			$loopData = array();
			while($row = mysql_fetch_assoc($result)){
				$arr = array();
			    foreach($row as $key => $val){
			        $arr[$key] = $val;
			    }
			    array_push($loopData,$arr);
			}


			$response['success'] = 1;
			$response['message'] = 'Authentication successfull';
			$response['data'] = $loopData;	
		}else{

			$response['success'] = 0;
			$response['message'] = 'Authentication failed';
			$response['data'] = array();	
		}

		mysql_close($link);
	}else {
		if(is_null($id) && $method == "GET") {
			// get all records
			$query = "SELECT * FROM $entity";
		}

		if(!is_null($id) && $method == "GET") {
			// get one record
			$query = "SELECT * FROM $entity WHERE id=$id";
		}

		if(is_null($id) && $method == "POST") {
			// insert one record
			$query = "INSERT INTO $entity (";
			$i = 0;

			foreach($_POST as $key => $value) {
				if($i > 0) {
					$query .= ",";
				}
				$query .= $key;
				$i++;
			}

			$query .=") ";

			$query .= "VALUES (";;
			$i = 0;
			foreach($_POST as $key => $value) {
				if($i > 0) {
					$query .= ",";
				}
				$query .= "'".$value."'";
				$i++;
			}
			$query .=")";
		}

		if(!is_null($id) && $method == "PUT") {
			// update one record
			$query = "UPDATE $entity SET ";
			$i = 0;
			

			$raw_data = file_get_contents('php://input');
			$boundary = substr($raw_data, 0, strpos($raw_data, "\r\n"));

			// Fetch each part
			$parts = array_slice(explode($boundary, $raw_data), 1);
			$data = array();

			foreach ($parts as $part) {
			    // If this is the last part, break
			    if ($part == "--\r\n") break; 

			    // Separate content from headers
			    $part = ltrim($part, "\r\n");
			    list($raw_headers, $body) = explode("\r\n\r\n", $part, 2);

			    // Parse the headers list
			    $raw_headers = explode("\r\n", $raw_headers);
			    $headers = array();
			    foreach ($raw_headers as $header) {
			        list($name, $value) = explode(':', $header);
			        $headers[strtolower($name)] = ltrim($value, ' '); 
			    } 

			    // Parse the Content-Disposition to get the field name, etc.
			    if (isset($headers['content-disposition'])) {
			        $filename = null;
			        preg_match(
			            '/^(.+); *name="([^"]+)"(; *filename="([^"]+)")?/', 
			            $headers['content-disposition'], 
			            $matches
			        );
			        list(, $type, $name) = $matches;
			        isset($matches[4]) and $filename = $matches[4]; 

			        // handle your fields here
			        switch ($name) {
			            // this is a file upload
			            case 'userfile':
			                 file_put_contents($filename, $body);
			                 break;

			            // default for all other files is to populate $data
			            default: 
			                 $data[$name] = substr($body, 0, strlen($body) - 2);
			                 break;
			        } 
			    }

			}

			foreach ($data as $key => $value) {

				if($i > 0) {
					$query .= ",";
				}
				$query .= "$key = '$value'";
				$i++;
			}
			$query .=" WHERE id=$id";
		}

		if(!is_null($id) && $method == "DELETE") {
			// delete one record
			$query = "DELETE FROM $entity WHERE id = $id";
		}	

		
		$link = mysql_connect($host, $user, $password);	
		mysql_select_db($database);
		$result = mysql_query( $query, $link );
		if($result) {
			switch($method) {

				case 'GET' :
							$loopData = array();
							while($row = mysql_fetch_assoc($result)){
								$arr = array();
							    foreach($row as $key => $val){
							        $arr[$key] = $val;
							    }
							    array_push($loopData,$arr);
							}

							$response['success'] = 1;
							$response['message'] = 'Retrieved all data';
							$response['data'] = $loopData;					
							break;

				case 'POST' :

							$response['success'] = 1;
							$response['message'] = 'Record inserted successfully';
							$response['data'] = array();
							break;

				case 'PUT' :

							$response['success'] = 1;
							$response['message'] = 'Record updated successfully';
							$response['data'] = array();
							break;

				case 'DELETE' :

							$response['success'] = 1;
							$response['message'] = 'Record deleted successfully';
							$response['data'] = array();
							break;
			}
		}else{
			$response['success'] = 0;
			$response['message'] = 'Error ocurred. Cannot process data.';
			$response['data'] = array();
		}
		
		
		mysql_close($link);
	}

	
}
header("Access-Control-Allow-Origin: *");
header("Content-Typ:application/json");
echo json_encode($response);
die();