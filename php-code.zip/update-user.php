<?php 
$host = '148.72.232.171';
$database = 'tekSpeaks';
$user = 'root';
$password = 'tekspeaks_123';

$response = array("success" => 0 , 'message' => 'cannot process data', 'data' => array());

// update one record
$params = json_decode(file_get_contents('php://input'),true);

$id = $params['id'];
$query = "UPDATE user SET ";
$i = 0;


$data = $_POST;

foreach ($data as $key => $value) {

	if($i > 0) {
		$query .= ",";
	}
	$query .= "$key = '$value'";
	$i++;
}
$query .=" WHERE id=$id";

$link = mysql_connect($host, $user, $password);	
mysql_select_db($database);
$result = mysql_query( $query, $link );

$response['success'] = 1;
$response['message'] = 'Record updated successfully';
$response['data'] = array();
mysql_close($link);

header("Access-Control-Allow-Origin: *");
header("Content-Typ:application/json");
echo json_encode($response);
die();