<?php 
$host = '148.72.232.171';
$database = 'tekSpeaks';
$user = 'root';
$password = 'tekspeaks_123';

$response = array("success" => 0 , 'message' => 'cannot process data', 'data' => array());

$params = json_decode(file_get_contents('php://input'),true);

$id = $params['id'];
$query = "DELETE FROM contact WHERE id = $id";

$link = mysql_connect($host, $user, $password);	
mysql_select_db($database);
$result = mysql_query( $query, $link );

$response['success'] = 1;
$response['message'] = 'Record deleted successfully';
$response['data'] = array();mysql_close($link);

header("Access-Control-Allow-Origin: *");
header("Content-Typ:application/json");
echo json_encode($response);
die();