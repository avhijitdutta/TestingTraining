<?php 
$host = '148.72.232.171';
$database = 'tekSpeaks';
$user = 'root';
$password = 'tekspeaks_123';

$response = array("success" => 0 , 'message' => 'cannot process data', 'data' => array());

$query = "SELECT * FROM user";

$link = mysql_connect($host, $user, $password);	
mysql_select_db($database);
$result = mysql_query( $query, $link );

$loopData = array();
while($row = mysql_fetch_assoc($result)){
	$arr = array();
    foreach($row as $key => $val){
        $arr[$key] = $val;
    }
    array_push($loopData,$arr);
}

$response['success'] = 1;
$response['message'] = 'Retrieved all data';
$response['data'] = $loopData;	
mysql_close($link);

header("Access-Control-Allow-Origin: *");
header("Content-Typ:application/json");
echo json_encode($response);
die();