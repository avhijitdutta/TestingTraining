<?php 
$host = '148.72.232.171';
$database = 'tekSpeaks';
$user = 'root';
$password = 'tekspeaks_123';

$response = array("success" => 0 , 'message' => 'cannot process data', 'data' => array());

// insert one record
$query = "INSERT INTO user (";
$i = 0;

foreach($_POST as $key => $value) {
	if($i > 0) {
		$query .= ",";
	}
	$query .= $key;
	$i++;
}

$query .=") ";

$query .= "VALUES (";;
$i = 0;
foreach($_POST as $key => $value) {
	if($i > 0) {
		$query .= ",";
	}
	$query .= "'".$value."'";
	$i++;
}
$query .=")";


$response['success'] = 1;
$response['message'] = 'Record inserted successfully';
$response['data'] = array();
mysql_close($link);
header("Access-Control-Allow-Origin: *");
header("Content-Typ:application/json");
echo json_encode($response);
die();