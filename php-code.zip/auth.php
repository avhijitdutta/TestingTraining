<?php
$host = '148.72.232.171';
$database = 'tekSpeaks';
$user = 'root';
$password = 'tekspeaks_123';

$response = array("success" => 0 , 'message' => 'cannot process data', 'data' => array());

$params = json_decode(file_get_contents('php://input'),true);
$requestEmail = $params['email'];
$requestPassword = $params['password'];
$query = "SELECT * FROM user WHERE email='".$requestEmail."' AND password='".$requestPassword."'";

$link = mysql_connect($host, $user, $password);	
mysql_select_db($database);
$result = mysql_query($query);
$num_rows = mysql_num_rows( $result);

if($num_rows > 0) {
	// authentication successfull

	$loopData = array();
	while($row = mysql_fetch_assoc($result)){
		$arr = array();
	    foreach($row as $key => $val){
	        $arr[$key] = $val;
	    }
	    array_push($loopData,$arr);
	}


	$response['success'] = 1;
	$response['message'] = 'Authentication successfull';
	$response['data'] = $loopData;	

}
mysql_close($link);

header("Access-Control-Allow-Origin: *");
header("Content-Typ:application/json");
echo json_encode($response);
die();
